#include <SFML/Graphics.hpp>
#include <vector>
#include <cstdlib>
#include <ctime>

int main() {
    sf::RenderWindow window(sf::VideoMode(600, 600), "Snake Game - Game Over Added");
    window.setFramerateLimit(10);

    const float blockSize = 20.f;
    std::vector<sf::Vector2f> snake;
    snake.push_back({300.f, 300.f});

    sf::Vector2f direction(blockSize, 0.f);

    sf::RectangleShape block(sf::Vector2f(blockSize, blockSize));
    block.setFillColor(sf::Color::Green);

    std::srand(static_cast<unsigned>(std::time(nullptr)));
    sf::RectangleShape food(sf::Vector2f(blockSize, blockSize));
    food.setFillColor(sf::Color::Red);
    food.setPosition((std::rand() % 30) * blockSize, (std::rand() % 30) * blockSize);

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();

            if (event.type == sf::Event::KeyPressed) {
                if (event.key.code == sf::Keyboard::Up && direction.y == 0)
                    direction = {0.f, -blockSize};
                else if (event.key.code == sf::Keyboard::Down && direction.y == 0)
                    direction = {0.f, blockSize};
                else if (event.key.code == sf::Keyboard::Left && direction.x == 0)
                    direction = {-blockSize, 0.f};
                else if (event.key.code == sf::Keyboard::Right && direction.x == 0)
                    direction = {blockSize, 0.f};
            }
        }

        // Move tail segments
        for (int i = snake.size() - 1; i > 0; --i)
            snake[i] = snake[i - 1];

        // Move head
        snake[0] += direction;

        // Wrap edges
        if (snake[0].x < 0) snake[0].x = 580;
        if (snake[0].x > 580) snake[0].x = 0;
        if (snake[0].y < 0) snake[0].y = 580;
        if (snake[0].y > 580) snake[0].y = 0;

        // ✅ Game Over: head hits tail
        for (size_t i = 1; i < snake.size(); ++i) {
            if (snake[0] == snake[i]) {
                window.close();  // Ends the game
            }
        }

        // Food collision
        block.setPosition(snake[0]);
        if (block.getGlobalBounds().intersects(food.getGlobalBounds())) {
            snake.push_back(snake.back());
            food.setPosition((std::rand() % 30) * blockSize, (std::rand() % 30) * blockSize);
        }

        window.clear();
        window.draw(food);

        // Draw snake
        for (auto& segment : snake) {
            block.setPosition(segment);
            window.draw(block);
        }

        window.display();
    }

    return 0;
}